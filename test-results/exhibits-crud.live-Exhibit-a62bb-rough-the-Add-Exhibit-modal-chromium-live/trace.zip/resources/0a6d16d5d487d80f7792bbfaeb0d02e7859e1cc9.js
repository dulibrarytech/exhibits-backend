const homeModule=(function(){"use strict";const t=endpointsModule.get_app_path();let e={};return e.init=async function(){authModule.check_user_auth_data()===!1&&await authModule.get_auth_user_data(),await exhibitsModule.init(),history.replaceState({},"",t+"/exhibits"),history.pushState({},"",t+"/exhibits")},e})();(async()=>await homeModule.init())();
//# sourceMappingURL=home.module.min.js.map
